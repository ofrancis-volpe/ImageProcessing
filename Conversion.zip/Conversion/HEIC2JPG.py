from PIL import Image
import os
import pillow_heif

def get_file_path():
    """Takes file path input, defaults to current directory if no input."""
    file_path = input("Enter file path (leave empty for current directory): ")
    if not file_path:  # Checks if input is empty
        file_path = "."  # Sets default to current directory
    
    # Expand user paths (e.g., ~)
    file_path = os.path.expanduser(file_path)
    
    # Get the absolute path
    file_path = os.path.abspath(file_path)
    
    return file_path

pillow_heif.register_heif_opener()

def convert_heic_to_jpg(heic_filepath, jpg_filepath):
    """Converts a single HEIC image to JPG."""
    try:
        img = Image.open(heic_filepath)
        img.convert('RGB').save(jpg_filepath, "jpeg")
        return True
    except Exception as e:
        print(f"Error converting {heic_filepath}: {e}")
        return False

def batch_convert_heic_to_jpg(directory):
    """Converts all HEIC images in a directory to JPG."""
    for filename in os.listdir(directory):
        if filename.lower().endswith(('.heic', '.heif')):
            heic_filepath = os.path.join(directory, filename)
            jpg_filepath = os.path.splitext(heic_filepath)[0] + ".jpg"
            convert_heic_to_jpg(heic_filepath, jpg_filepath)

# Example usage:
directory_path = get_file_path()
#directory_path = "C://Users//Odin.Francis//Documents//Travel//Atsugi 04-25//Test"  # Replace with the actual path
batch_convert_heic_to_jpg(directory_path)